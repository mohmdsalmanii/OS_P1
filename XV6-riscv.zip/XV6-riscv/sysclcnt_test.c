 GNU nano 7.2                    sysclcnt_test.c                     Modified  
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
  int n1, n2;

  n1 = sysclcnt();
  printf(" first: %d\n", n1);

  
  n2 = sysclcnt();
  printf(" second: %d\n", n2);

  
  exit(0);
