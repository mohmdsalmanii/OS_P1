#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"
struct spinlock tickslock;
uint ticks;

extern char trampoline[], uservec[], userret[];

// from kernelvec.S
void kernelvec();

extern int devintr(void);

extern uint tajmer;
extern uint tajmerMAX;

void
trapinit(void)
{
  initlock(&tickslock, "time");
}

void
trapinithart(void)
{
  w_stvec((uint64)kernelvec);
}

//
// user space trap handler
//
void
usertrap(void)
{
  int which_dev = 0;

  if((r_sstatus() & SSTATUS_SPP) != 0)
    panic("usertrap: not from user mode");

  // switch traps to kerneltrap
  w_stvec((uint64)kernelvec);

  struct proc *p = myproc();

  // save user pc
  p->trapframe->epc = r_sepc();

  if(r_scause() == 8){
    // syscall
    if(p->killed)
      kexit(-1);

    p->trapframe->epc += 4;
    intr_on();
    syscall();

  } else if((which_dev = devintr()) != 0){
    // device interrupt

  } else {
    printf("usertrap(): unexpected scause %p pid=%d\n",
           r_scause(), p->pid);
    printf("            sepc=%p stval=%p\n",
           r_sepc(), r_stval());
    p->killed = 1;
  }

  if(p->killed)
    kexit(-1);

  // time slice handling
  if(which_dev == 2){
    if(p){ 
            p->executionTime++;   // زمان واقعی اجرا
            p->vruntime += 1;     // vruntime برای CFS
        }

        tajmer++;
        if(tajmer >= tajmerMAX){
            tajmer = 0;
            yield();  // تعویض فرآیند
  }

	usertrapret();  
}}

//
// return to user space
//
void
usertrapret(void)
{
  struct proc *p = myproc();

  intr_off();

  // set trampoline trap vector
  w_stvec(TRAMPOLINE + (uservec - trampoline));

  // set trapframe for trampoline
  p->trapframe->kernel_satp   = r_satp();
  p->trapframe->kernel_sp     = p->kstack + PGSIZE;
  p->trapframe->kernel_trap   = (uint64)usertrap;
  p->trapframe->kernel_hartid = r_tp();

  // user mode, interrupts on
  uint64 x = r_sstatus();
  x &= ~SSTATUS_SPP;
  x |= SSTATUS_SPIE;
  w_sstatus(x);

  w_sepc(p->trapframe->epc);

  uint64 satp = MAKE_SATP(p->pagetable);
  uint64 fn = TRAMPOLINE + (userret - trampoline);
  ((void (*)(uint64, uint64))fn)(TRAPFRAME, satp);
}

//
// timer interrupt
//
void
clockintr(void)
{
  acquire(&tickslock);
  ticks++;
  wakeup(&ticks);
  release(&tickslock);

}

//
// kernel trap handler
//
void
kerneltrap(void)
{
  int which_dev = 0;
  uint64 sepc = r_sepc();
  uint64 sstatus = r_sstatus();

  if((sstatus & SSTATUS_SPP) == 0)
    panic("kerneltrap: not from supervisor mode");
  if(intr_get())
    panic("kerneltrap: interrupts enabled");

  which_dev = devintr();
  if(which_dev == 0){
    printf("scause %p\n", r_scause());
    printf("sepc=%p stval=%p\n", r_sepc(), r_stval());
    panic("kerneltrap");
  }

  if(which_dev == 2){
    if(cpuid() == 0)
      clockintr();

    if(myproc() && myproc()->state == RUNNING){
    	myproc()->vruntime += 1024;
    }
  }

  w_sepc(sepc);
  w_sstatus(sstatus);
}

//
// device interrupt handler
//
int
devintr(void)
{
  uint64 scause = r_scause();

  // external interrupt via PLIC
  if((scause & 0x8000000000000000L) && (scause & 0xff) == 9){
    int irq = plic_claim();

    if(irq == UART0_IRQ){
      uartintr();
    } else if(irq == VIRTIO0_IRQ){
      virtio_disk_intr();
    } else if(irq){
      printf("unexpected irq %d\n", irq);
    }

    if(irq){
    	plic_complete(irq);
    	}
    	return 1;
 	 }

  if(scause == 0x8000000000000005L){
  	return 2;
  	}
  if(scause == 0x8000000000000001L){
    w_sip(r_sip() & ~2);
    return 2;
  }

  return 0;
}
