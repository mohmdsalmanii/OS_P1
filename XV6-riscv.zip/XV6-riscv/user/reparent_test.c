#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
    int pid1 = fork();
    if(pid1 == 0){
        // Child 1
        int pid2 = fork();
        if(pid2 == 0){
            // Child 2
            sleep(50); 
            printf("Child2 after reparenting. PID = %d\n", getpid());
            exit(0);
        }

        // Parent1 exits 
        exit(0);
    }

    // Grandparent
    wait(0);

    sleep(100); // فرصت برای reparenting
    printf("Grandparent (%d): loading..", getpid());

    wait(0); 
    printf("test completed.\n");
    exit(0);
}
